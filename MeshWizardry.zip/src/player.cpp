#include "player.h"
#include "input.h"

#include <iostream>

Player::Player(Camera3D camera) {
  position = camera.position;
  camera = camera;
}
void Player::move(InputState input) {
  if (input.forward)
    position.x += 2;
  if (input.backward)
    position.x -= 2;
  if (input.left)
    position.z -= 2;
  if (input.right)
    position.z += 2;
  std::cout << position.x << position.y << position.z << "\n";
  std::cout << camera.position.x << camera.position.y << camera.position.z
            << "\n";
}
void Player::updateCamera() { camera.position = position; }
